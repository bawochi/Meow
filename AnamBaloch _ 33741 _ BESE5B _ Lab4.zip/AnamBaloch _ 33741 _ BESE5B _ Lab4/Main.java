import java.sql.*;

public class Main {
    public static void main(String[] args) {
        String DB_URL = "jdbc:mysql://localhost/lab4?useSSL=false";
        String DB_USER = "root";
        String DB_PASS = "";

        Connection conn = null;
        Statement stmt = null;

        try{
            Class.forName("com.mysql.jdbc.Driver");

            conn = DriverManager.getConnection(DB_URL,DB_USER,DB_PASS);
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM sakila.actor ");

            while(rs.next())
                System.out.println(rs.getString("first_name"));

        } catch(Exception e){
            e.printStackTrace();
        } finally {

        }
    }
}