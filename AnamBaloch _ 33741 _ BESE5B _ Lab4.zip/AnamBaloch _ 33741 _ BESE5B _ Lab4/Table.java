//class that will be inherited by all the different types of table
public class Table {
	String type;
	String name;
	boolean occupied;
	int persons;
	int time;
	
	Table(String type,int persons)
	{
		this.type=type;
		this.persons=persons;
		occupied=false;
	}
	
	public void setName(String name)
	{
		this.name=name;
	}
	public void setOccupied(boolean occupied)
	{
		this.occupied=occupied;
	}
	public void setPersons(int persons)
	{
		this.persons=persons;
	}
	public void setTime(int time)
	{
		this.time=time;
	}
	
	public String getName()
	{
		return name;
	}
	public boolean getOccupied()
	{
		return occupied;
	}
	public int getPersons()
	{
		return persons;
	}
	public int getTime()
	{
		return time;
	}
	

	
}
