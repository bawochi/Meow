package pk.edu.nust.seecs.gradebook.BO;

import pk.edu.nust.seecs.gradebook.dao.CloDao;
import pk.edu.nust.seecs.gradebook.dao.ContentDao;
import pk.edu.nust.seecs.gradebook.dao.GradeDao;
import pk.edu.nust.seecs.gradebook.entity.Content;
import pk.edu.nust.seecs.gradebook.entity.Grade;

/**
 * Created by Toshiba on 4/19/2017.
 */
public class GradeBO {
    private GradeDao gradedao;
    public GradeBO(){
        gradedao = new GradeDao();
    }
    public void addGrade(Grade c){
        gradedao.addGrade(c);
    }

    public void updateGrade(Grade c){
        gradedao.updateGrade(c);
    }

    public void deleteGrade(int id){
        gradedao.deleteGrade(id);
    }
}
