package com.example.toshiba.myapplication;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;

import java.util.Arrays;
import java.util.Scanner;

public class MainActivity {

    int MAX_PLAYERS = 2;
    int[] snakesA = null;
    int[] snakesB = null;
    int[] laddersA = null;
    int[] laddersB = null;
    int totalPos = 100;
    int[] players = null;
    int[] scores = null;
    int n = 0;

    public void init() throws Exception {
        //Position of snakes for eg. snake at 31 bites and fall to 14
        String snakes = "31-14,37-17,73-53,78-39,92-35,99-7";
        //Position of ladders for eg. Ladder at 5 takes to 25
        String ladders = "5-25,10-29,22-41,28-55,44-95,70-89,79-81";

        String[] snakesArr = snakes.split(",");
        String[] laddersArr = ladders.split(",");

        snakesA = new int[snakesArr.length];
        snakesB = new int[snakesArr.length];

        laddersA = new int[laddersArr.length];
        laddersB = new int[laddersArr.length];

        int i=0;
        for(String s: snakesArr) {
            String[] x = s.split("-");
            snakesA[i] = Integer.parseInt(x[0]);
            snakesB[i] = Integer.parseInt(x[1]);
            i++;
        }

        i=0;
        for(String s: laddersArr) {
            String[] x = s.split("-");
            laddersA[i] = Integer.parseInt(x[0]);
            laddersB[i] = Integer.parseInt(x[1]);
            i++;
        }

        //Read total players required as input
        System.out.println("Enter number of players : between 2 and " +MAX_PLAYERS);
        Scanner scan=new Scanner(System.in);
        n=scan.nextInt();
        scan.close();
        if( n < 2 && n > MAX_PLAYERS ) {
            System.exit(-1);
        }

        players = new int[ n ];
        scores = new int[ n ];
    }

    public boolean isSnake( int pos ) {
        int indx = Arrays.binarySearch(snakesA, pos);
        boolean result = (indx < 0)? false: true;
        return result;
    }

    public boolean isLadder( int pos ) {
        int indx = Arrays.binarySearch(laddersA, pos);
        boolean result = (indx < 0)? false: true;
        return result;
    }

    public int getSnake( int pos ) {
        int indx = Arrays.binarySearch(snakesA, pos);
        return snakesB[indx];
    }

    public int getLadder( int pos ) {
        int indx = Arrays.binarySearch(laddersA, pos);
        return laddersB[indx];
    }

    public int throwDice() {
        int i = 0;

        while( i == 0) {
            i = (int)(Math.random()*100);
            i = i%13;
        }
        return i;
    }

    public void game() throws Exception {

        init();

        int i=0;

        while( true ) {
            int v = throwDice();
            char user = (char)('A' + i);
            int score = scores[ i ] + v;
            if( score >= totalPos ) {
                System.out.println("User : " +user+ " got " +v+ ".WINNER!!");
                break;
            }
            if( isLadder(score) ) {
                score = getLadder(score);
                System.out.println("User : " +user+ " got " +v+ " climbed ladder to: " +score);
                scores[i] = score;
            } else if( isSnake(score)) {
                score = getSnake(score);
                System.out.println("User : " +user+ " got " +v+ " snake bit to: " +score);
                scores[i] = score;
            } else {
                System.out.println("User : " +user+ " got " +v+ " and moved to: " +score);
                scores[i] = score;
            }

            i++;
            if( i == n) {
                i = 0;
            }
        }

    }

    /**
     * @param args
     */
    public static void main(String[] args) throws Exception {
        MainActivity snakeAndLadder = new MainActivity();
        snakeAndLadder.game();
    }

}

class Snake {
    int start;
    int end;

    public Snake(int start, int end) {
        this.start = start;
        this.end = end;
    }
}

class Ladder {
    int start;
    int end;

    public Ladder(int start, int end) {
        this.start = start;
        this.end = end;
    }
}