#include <iostream>



using namespace std;

class matrix{
public:
	int **mat;
	int rows = 0;
	int columns = 0;

	matrix(int r, int c){
		rows = r;
		columns = c;

		mat = new int*[r];
		for (int i = 0; i < r; i++){
			mat[i] = new int[c];
		}
	}

	void populateMatrix(){
		int temp;
		for (int i = 0; i < rows; i++){
			for (int j = 0; j < columns; j++){
				cout << "Polpulate matrix [" << i + 1 << "][" << j + 1 << "] : ";

				cin >> temp;
				mat[i][j] = temp;
			}
		}
	}

	void padding(){
		int temp;

		if (rows > columns)
			temp = rows;
		else
			temp = columns;

		int newSize = 1;
	while (newSize < temp){
			newSize *= 2;
		}

		matrix newMat(newSize, newSize);
		cout << "newSize = " << newSize << endl;

		for (int i = 0; i < newSize; i++){
			for (int j = 0; j < newSize; j++){
				if (i >= rows)
					newMat.mat[i][j] = 0;
				else if (j >= columns)
					newMat.mat[i][j] = 0;
				else
					newMat.mat[i][j] = mat[i][j];

			}
		}

		mat = newMat.mat;
		rows = newSize;
		columns = newSize;
	}

	void printMatrix(){
		for (int i = 0; i < rows; i++){
			for (int j = 0; j < columns; j++){
				cout << mat[i][j] << "  ";
			}
			cout << endl;
		}
	}


};


//Iterative Multiplication here
matrix iterativeMutiplication(matrix mat1, matrix mat2){
	int **A = mat1.mat;
	int **B = mat2.mat;

	int Cr = mat1.rows;
	int Cc = mat2.columns;
	int common = mat2.rows;
	int sum = 0;

	matrix ans(Cr, Cc);

	int** C = new int*[Cr];
	for (int i = 0; i < Cr; ++i)
		C[i] = new int[Cc];


	for (int i = 0; i < Cr; i++){
		for (int j = 0; j < Cc; j++){
			sum = 0;
			for (int k = 0; k < common; k++){
				sum = sum + A[i][k] * B[k][j];
			}
			C[i][j] = sum;
		}

	}

	ans.mat = C;

	return ans;
}

//Strassen Multiplication Algorithm
matrix strassenMultiplication(matrix &ans, matrix A, matrix B, int n, int m){

	if (m - n > 2){
		
		strassenMultiplication(ans, A, B, n, ((m - n) / 2) - 1);
		strassenMultiplication(ans, A, B, ((m - n) / 2), m);
	}
	else{
		int M1 = (A.mat[n + 0][n + 0] + A.mat[n + 1][n + 1]) * (A.mat[n + 0][n + 0] + A.mat[n + 1][n + 1]);
		int M2 = (A.mat[n + 1][n + 0] + A.mat[n + 1][n + 1]) * B.mat[n + 0][n + 0];
		int M3 = A.mat[n + 0][n + 0] * (B.mat[n + 0][n + 1] - B.mat[n + 1][n + 1]);
		int M4 = A.mat[n + 1][n + 1] * (B.mat[n + 1][n + 0] - B.mat[n + 0][n + 0]);
		int M5 = (A.mat[n + 0][n + 0] + A.mat[n + 0][n + 1]) * B.mat[n + 1][n + 1];
		int M6 = (A.mat[n + 1][n + 0] - A.mat[n + 0][n + 0]) * (B.mat[n + 0][n + 0] + B.mat[n + 0][n + 1]);
		int M7 = (A.mat[n + 0][n + 1] - A.mat[n + 1][n + 1]) * (B.mat[n + 1][n + 0] + B.mat[n + 1][n + 1]);

		ans.mat[n + 0][n + 0] = M1 + M4 - M5 + M7;
		ans.mat[n + 0][n + 1] = M3 + M5;
		ans.mat[n + 1][n + 0] = M2 + M4;
		ans.mat[n + 1][n + 1] = M1 - M2 + M3 + M6;



	}
	return ans;
}

matrix strassen(matrix A, matrix B){
	matrix answer(A.rows, B.columns);
	return strassenMultiplication(answer, A, B, 0, A.rows);
}

void padding(matrix &A, matrix &B){
	int temp;

	if (A.rows > A.columns){
		if (A.rows > B.columns){
			temp = A.rows;
		}
	}
	else if (A.columns > A.rows){
		if (A.columns > B.columns){
			temp = A.columns;
		}
	}
	else if (B.columns > A.columns){
		if (B.columns > A.rows){
			temp = B.columns;
		}
	}


	int newSize = 1;
	while (newSize < temp){
		newSize *= 2;
	}
	//Make matrix A 
	matrix newMatA(newSize, newSize);
	cout << "newSize = " << newSize << endl;

	for (int i = 0; i < newSize; i++){
		for (int j = 0; j < newSize; j++){
			if (i >= A.rows)
				newMatA.mat[i][j] = 0;
			else if (j >= A.columns)
				newMatA.mat[i][j] = 0;
			else
				newMatA.mat[i][j] = A.mat[i][j];

		}
	}


	A.mat = newMatA.mat;
	A.rows = newSize;
	A.columns = newSize;

	//Make matrix B
	matrix newMatB(newSize, newSize);
	cout << "Size of Matrix = " << newSize << endl;

	for (int i = 0; i < newSize; i++){
		for (int j = 0; j < newSize; j++){
			if (i >= B.rows)
				newMatB.mat[i][j] = 0;
			else if (j >= B.columns)
				newMatB.mat[i][j] = 0;
			else
				newMatB.mat[i][j] = B.mat[i][j];

		}
	}

	B.mat = newMatB.mat;
	B.rows = newSize;
	B.columns = newSize;
}

void multiplyMat(int **input1, int **input2, int **resultMat,
	int resultRows, int resultcolumns, int mat1columns) {

	for (int i = 0; i < resultRows; i++) {
		resultMat[i] = new int[resultcolumns];
		for (int j = 0; j < resultcolumns; j++) {
			resultMat[i][j] = 0;
			for (unsigned int k = 0; k < mat1columns; k++) {
				resultMat[i][j] += input1[i][k] * input2[k][j];
			}
		}
	}
}

void addMat(int **input1, int **input2, int **resultMat, int matSize) {
	for (int i = 0; i < matSize; i++) {
		resultMat[i] = new int[matSize];
		for (int j = 0; j < matSize; j++) {
			resultMat[i][j] = input1[i][j] + input2[i][j];
		}
	}
}

void subMat(int **input1, int **input2, int **resultMat, int matSize) {
	for (int i = 0; i < matSize; i++) {
		resultMat[i] = new int[matSize];
		for (int j = 0; j < matSize; j++) {
			resultMat[i][j] = input1[i][j] - input2[i][j];
		}
	}
}

void multiplyMatStras(int **input1, int **input2, int **resultMat, int matSize) {
	if (matSize <= 2) {
		
		multiplyMat(input1, input2, resultMat, matSize, matSize, matSize); //base condition.
	}
	else {
		int matNewSize = matSize / 2;
	//Creating square matrices for A
	
		int **A00 = new int *[matSize];
		int **A01 = new int *[matSize];
		int **A10 = new int *[matSize];
		int **A11 = new int *[matSize];
		int **B00 = new int *[matSize];
		int **B01 = new int *[matSize];
		int **B10 = new int *[matSize];
		int **B11 = new int *[matSize];

		
		//splitting the input arrays into 4 subarrays
		

		for (int i = 0; i < matNewSize; i++) {
			A00[i] = new int[matSize];
			A01[i] = new int[matSize];
			A10[i] = new int[matSize];
			A11[i] = new int[matSize];
			B00[i] = new int[matSize];
			B01[i] = new int[matSize];
			B10[i] = new int[matSize];
			B11[i] = new int[matSize];
			for (int j = 0; j < matNewSize; j++) {

				A00[i][j] = input1[i][j];
				A01[i][j] = input1[i][j + matNewSize];
				A10[i][j] = input1[i + matNewSize][j];
				A11[i][j] = input1[i + matNewSize][j + matNewSize];

				B00[i][j] = input2[i][j];
				B01[i][j] = input2[i][j + matNewSize];
				B10[i][j] = input2[i + matNewSize][j];
				B11[i][j] = input2[i + matNewSize][j + matNewSize];

			}
		}

		int **addTemp1 = new int *[matSize];
		int **addTemp2 = new int *[matSize];
		int **addTemp3 = new int *[matSize];
		int **subTemp1 = new int *[matSize];
		int **subTemp2 = new int *[matSize];
		int **m1 = new int *[matSize];
		int **m2 = new int *[matSize];
		int **m3 = new int *[matSize];
		int **m4 = new int *[matSize];
		int **m5 = new int *[matSize];
		int **m6 = new int *[matSize];
		int **m7 = new int *[matSize];


		//Calculating M1

		addMat(A00, A11, addTemp1, matNewSize);
		addMat(B00, B11, addTemp2, matNewSize);

		multiplyMatStras(addTemp1, addTemp2, m1, matNewSize);



		//Calculating M2

		addMat(A10, A11, addTemp3, matNewSize);
		multiplyMatStras(addTemp3, B00, m2, matNewSize);


		//Calculating M3

		subMat(B01, B11, subTemp1, matNewSize);
		multiplyMatStras(A00, subTemp1, m3, matNewSize);


		//Calculating M4

		subMat(B10, B00, subTemp2, matNewSize);
		multiplyMatStras(A11, subTemp2, m4, matNewSize);



		//Calculating M5


		addMat(A00, A01, addTemp1, matNewSize);
		multiplyMatStras(addTemp1, B11, m5, matNewSize);

		//Calculating M6

		subMat(A10, A00, subTemp1, matNewSize);
		addMat(B00, B01, addTemp2, matNewSize);
		multiplyMatStras(subTemp1, addTemp2, m6, matNewSize);

		//Calculating M7


		subMat(A01, A11, subTemp2, matNewSize);
		addMat(B10, B11, addTemp1, matNewSize);

		multiplyMatStras(subTemp2, addTemp1, m7, matNewSize);



		int **C00 = new int *[matSize];
		int **C01 = new int *[matSize];
		int **C10 = new int *[matSize];
		int **C11 = new int *[matSize];


		//Calculating C00

		addMat(m1, m4, addTemp1, matNewSize);
		addMat(addTemp1, m7, addTemp2, matNewSize);
		subMat(addTemp2, m5, C00, matNewSize);


		//Calculating C01

		addMat(m3, m5, C01, matNewSize);

		// Calculating C10

		addMat(m2, m4, C10, matNewSize);

		//Calculating C11

		addMat(m1, m3, addTemp1, matNewSize);
		addMat(addTemp1, m6, addTemp2, matNewSize);
		subMat(addTemp2, m2, C11, matNewSize);



		//Combining the sub matrices now

		for (int i = 0; i < matNewSize; i++) {
			resultMat[i] = new int[matSize];
			resultMat[i + matNewSize] = new int[matSize];
			for (int j = 0; j < matNewSize; j++) {
				resultMat[i][j] = C00[i][j];
				resultMat[i][j + matNewSize] = C01[i][j];
				resultMat[i + matNewSize][j] = C10[i][j];
				resultMat[i + matNewSize][j + matNewSize] = C11[i][j];
			}
		}

	}
}

void initMat(int **matrix, int rows, int columns) {
	for (int row_Ite = 0; row_Ite < rows; row_Ite++) {
		matrix[row_Ite] = new int[columns];
		for (int col_Ite = 0; col_Ite < columns; col_Ite++) {
			matrix[row_Ite][col_Ite] = row_Ite + col_Ite;
		}
	}
}

void displayMat(int **matrix, int rows, int columns) {
	for (int i = 0; i < rows; i++) {

		for (int j = 0; j < columns; j++) {
			cout << matrix[i][j] << "   ";
		}
		cout << endl;
	}
}
