//#include"lab2.h"
//
//void main(){
//
//	matrix m1(2, 3), m2(3, 2);
//	cout << "Matrix 1:\n\n";
//	m1.populateMatrix();
//	cout << "\nMatrix 2:\n\n";
//	m2.populateMatrix();
//
//
//	padding(m1, m2);
//
//	cout << "\n\nMatrix m1: \n\n";
//	m1.printMatrix();
//
//	cout << "\n\nMatrix m2: \n\n";
//	m2.printMatrix();
//
//	cout << "\n\nNormal Mutiplication: \n\n";
//	matrix m3(m1.rows, m1.columns);
//	multiplyMat(m1.mat, m2.mat, m3.mat, m3.rows, m3.columns, m1.columns);
//	m3.printMatrix();
//
//	cout << "\n\nStrassen Multiplication: \n\n";
//	matrix m4(m1.rows, m1.columns);
//	multiplyMatStras(m1.mat, m2.mat, m4.mat, m1.rows);
//	m4.printMatrix();
//
//	//Difference Test
//	matrix m5(m1.rows, m1.columns);
//	subMat(m3.mat, m4.mat, m5.mat, m1.rows);
//	cout << "\n\nDifference:\n\n" << endl;
//	m5.printMatrix();
//
//
//	return;
//}