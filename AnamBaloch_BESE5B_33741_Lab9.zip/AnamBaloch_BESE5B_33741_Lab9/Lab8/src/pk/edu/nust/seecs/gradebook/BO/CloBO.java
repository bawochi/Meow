package pk.edu.nust.seecs.gradebook.BO;

import pk.edu.nust.seecs.gradebook.dao.CloDao;
import pk.edu.nust.seecs.gradebook.entity.Clo;

/**
 * Created by Toshiba on 4/19/2017.
 */
public class CloBO {
    private CloDao clodao;
    public CloBO(){
        clodao = new CloDao();
    }
    public void addClo(Clo c){
        clodao.addClo(c);
    }

    public void updateClo(Clo c){
        clodao.updateClo(c);
    }

    public void deleteClo(int id){
        clodao.deleteClo(id);
    }
}
