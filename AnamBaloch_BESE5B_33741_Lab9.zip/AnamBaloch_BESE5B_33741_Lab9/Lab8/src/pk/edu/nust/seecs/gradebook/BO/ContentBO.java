package pk.edu.nust.seecs.gradebook.BO;

import pk.edu.nust.seecs.gradebook.dao.CloDao;
import pk.edu.nust.seecs.gradebook.dao.ContentDao;
import pk.edu.nust.seecs.gradebook.entity.Clo;
import pk.edu.nust.seecs.gradebook.entity.Content;

/**
 * Created by Toshiba on 4/19/2017.
 */
public class ContentBO {
    private ContentDao contentdao;
    public ContentBO(){
        contentdao = new ContentDao();
    }
    public void addContent(Content c){
        contentdao.addContent(c);
    }

    public void updateContent(Content c){
        contentdao.updateContent(c);
    }

    public void deleteContent(int id){
        contentdao.deleteContent(id);
    }
}
