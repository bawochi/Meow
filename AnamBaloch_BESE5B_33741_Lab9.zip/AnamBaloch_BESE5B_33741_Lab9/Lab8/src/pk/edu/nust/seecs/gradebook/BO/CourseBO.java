package pk.edu.nust.seecs.gradebook.BO;

import pk.edu.nust.seecs.gradebook.dao.CloDao;
import pk.edu.nust.seecs.gradebook.dao.ContentDao;
import pk.edu.nust.seecs.gradebook.dao.CourseDao;
import pk.edu.nust.seecs.gradebook.entity.Content;
import pk.edu.nust.seecs.gradebook.entity.Course;

/**
 * Created by Toshiba on 4/19/2017.
 */
public class CourseBO {
    private CourseDao coursedao;
    public CourseBO(){
        coursedao = new CourseDao();
    }
    public void addCourse(Course c){
        coursedao.addCourse(c);
    }

    public void updateCourse(Course c){
        coursedao.updateCourse(c);
    }

    public void deleteCourse(int id){
        coursedao.deleteCourse(id);
    }
}
