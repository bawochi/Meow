package pk.edu.nust.seecs.gradebook.BO;

import pk.edu.nust.seecs.gradebook.dao.CloDao;
import pk.edu.nust.seecs.gradebook.dao.ContentDao;
import pk.edu.nust.seecs.gradebook.dao.TeacherDao;
import pk.edu.nust.seecs.gradebook.entity.Content;
import pk.edu.nust.seecs.gradebook.entity.Teacher;

/**
 * Created by Toshiba on 4/19/2017.
 */
public class TeacherBO {
    private TeacherDao teacherdao;
    public TeacherBO(){
        teacherdao = new TeacherDao();
    }
    public void addTeacher(Teacher c){
        teacherdao.addTeacher(c);
    }

    public void updateTeacher(Teacher c){
        teacherdao.updateTeacher(c);
    }

    public void deleteTeacher(int id){
        teacherdao.deleteTeacher(id);
    }
}
