//Calender is being imported for reservation date and time
import java.util.Scanner;
import java.util.Calendar;

public class Main {

	public static void main(String[] args) {
		
		
		Scanner scanner = new Scanner(System.in);
		int woof;
		int woof2;
		
		ExtraLargeTable e= new ExtraLargeTable();
		LargeTable l= new LargeTable();
		MediumTable m= new MediumTable();
		SmallTable s= new SmallTable();
		
		
		System.out.println("1.Customer");
		System.out.println("2.Administrator");
		woof=scanner.nextInt();
		
		while(true)
		{
			switch(woof)
			{
			case 1:
				scanner.nextLine();
				System.out.println("Press 1 to make a reservation.");
				System.out.println("Press 2 to check your reservation.");
				woof2=scanner.nextInt();
				switch(woof2)
				{
				case 1:
					int people;
					String name;
					int time;
					boolean meow=false;
					scanner.nextLine();
					System.out.println("For how many people do you want to make the reservation?");
					people=scanner.nextInt();
					
					System.out.println("For what time do you want make the reservation?");
					time=scanner.nextInt();
					
					if(people<=2)
						meow=s.checkAvailability(time);
					else if(people<=4)
						meow=m.checkAvailability(time);
					else if(people<=6)
						meow=l.checkAvailability(time);
					else if(people<=12)
					{
						
						meow=e.checkAvailability(time);
						
					}
					if(meow==false)
					{
						System.out.println("No space available, try another time.");
						break;
					}
					scanner.nextLine();
					System.out.println("Name for reservation:");
					name=scanner.next();
					if(people<=2)
						s.addReservation(name, time, people);
					else if(people<=4)
						m.addReservation(name, time, people);
					else if(people<=6)
						l.addReservation(name, time, people);
					else if(people<=12)
						e.addReservation(name, time, people);
					System.out.println("Your reservation is successful for"+time+":00 hours.");
					
					break;
				case 2:
					break;

				}
				break;
				
			case 2:
				scanner.nextLine();
				String password="cutiepie";
				int woof3;
				
				System.out.println("Enter the password");
				String npass=scanner.next();
				while(!scanner.next().equals(password))
				{
					System.out.println("Wrong password. Please try again.");
				}
				scanner.nextLine();
				System.out.println("Login Successful");
				System.out.println("Press 1 to view all reservations");
				woof3=scanner.nextInt();
				switch(woof3)
				{
					case 1:
						System.out.println("Extra Large Table:");
						e.printReservation();
						System.out.println("Large Table:");
						l.printReservation();
						System.out.println("Medium Table:");
						m.printReservation();
						System.out.println("Small Table:");
						s.printReservation();
						break;
					
				}
				
				break;
			}
			scanner.nextLine();
			System.out.println("1.Customer");
			System.out.println("2.Administrator");
			choice=scanner.nextInt();
		
		
	}

}
}
