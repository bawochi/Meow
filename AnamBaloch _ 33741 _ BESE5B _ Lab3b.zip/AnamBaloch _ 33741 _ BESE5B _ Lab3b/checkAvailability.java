//This class is there to check the avilability of the table in correspondence to the number of people reseerving the table

public class checkAvailability {
    //Giving names to all 16 tables
	public Table checkAvailability(String name,int persons,int time, Table t1,Table t2,Table t3,Table t4,Table t5,Table t6,Table t7,Table t8,Table t9,Table t10,Table t11,Table t12,Table t13,Table t14,Table t15,Table t16)
	{		

	    if(persons<=2)
		{
			if(time!=t13.getTime())
			{
				
			}
		}
		else if(persons<=4)
		{
			
		}
		else if(persons<=6)
		{
			
		}
		else if(persons<=12)
		{
			
		}
		
		
		Table temp=t1;
		return temp;
	}
}
