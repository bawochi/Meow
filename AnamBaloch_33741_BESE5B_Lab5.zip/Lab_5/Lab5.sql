Create schema Location;
Create table Location
