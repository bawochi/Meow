package com.mkyong.csv;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class CSVReader {

    public static void main(String[] args) {

        String csvFile = "C:\\Users\\Toshiba\\Desktop\\GeoLiteCity-Location.csv";
        String line = "";
        String cvsSplitBy = ",";

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {

            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] Location = line.split(cvsSplitBy);
                System.out.println("Location ID: " + Location.getlocId());
                System.out.println("Country: " + Location.getCountry());
                System.out.println("Region: " + Location.getRegion());
                System.out.println("Latitude:" + Location.getLatitude());
                System.out.println("Longitude:" + Location.getLongitude());
                System.out.println("MetroCode:" + Location.getMetroCode());
                System.out.println("AreaCode:" + Location.getAreaCode());


            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}