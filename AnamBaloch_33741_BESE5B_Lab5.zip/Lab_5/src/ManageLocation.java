
import java.util.List;
import java.util.Date;
import java.util.Iterator;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class ManageLocation {
    private static SessionFactory factory;
    public static void main(String[] args) {
        try{
            factory = new Configuration().configure().buildSessionFactory();
        }catch (Throwable ex) {
            System.err.println("Failed to create sessionFactory object." + ex);
            throw new ExceptionInInitializerError(ex);
        }
        ManageLocation ME = new ManageLocation();

      /* Add few Location records in database */
        Integer empID1 = ME.addLocation(1,"a","tri", 54000, 10.3, 32.1, 985,435);


      /* List down all the Locations */
        ME.listLocations();

    }
    /* Method to CREATE an Location in the database */
    public Integer addLocation(int locId,String country, String region, int postalcode, double longitude, double latitude, int metroCode, int areaCode){
        Session session = factory.openSession();
        Transaction tx = null;
        Integer LocationID = null;
        try{
            tx = session.beginTransaction();
            Location Location = new Location(locId, country, region, postalcode, longitude, latitude, metroCode, areaCode);
            LocationID = (Integer) session.save(Location);
            tx.commit();
        }catch (HibernateException e) {
            if (tx!=null) tx.rollback();
            e.printStackTrace();
        }finally {
            session.close();
        }
        return LocationID;
    }
    /* Method to  READ all the Locations */
    public void listLocations( ) {
        Session session = factory.openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            List Locations = session.createQuery("FROM Location").list();
            for (Iterator iterator =
                 Locations.iterator(); iterator.hasNext(); ) {
                Location Location = (Location) iterator.next();
                System.out.println("Location ID: " + Location.getlocId());
                System.out.println("Country: " + Location.getCountry());
                System.out.println("Region: " + Location.getRegion());
                System.out.println("Latitude:" + Location.getLatitude());
                System.out.println("Longitude:" + Location.getLongitude());
                System.out.println("MetroCode:" + Location.getMetroCode());
                System.out.println("AreaCode:" + Location.getAreaCode());
            }
            tx.commit();
        } catch (HibernateException e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
}