
public class Location {
    private int locId;
    private String country;
    private String region;
    private int postalcode;
    private double longitude;
    private double latitude;
    private int metroCode;
    private int areaCode;


    public Location() {}
    public Location(int locId,String country, String region, int postalcode, double longitude, double latitude, int metroCode, int areaCode) {
        this.locId = locId;
        this.country = country;
        this.region = region;
        this.postalcode = postalcode;
        this.longitude = longitude;
        this.latitude = latitude;
        this.metroCode = metroCode;
        this.areaCode = areaCode;
    }
    public int getlocId() {
        return locId;
    }
    public void setlocId( int locId ) {
        this.locId = locId;
    }
    public String getCountry() {
        return country;
    }
    public void setCountry( String country ) {
        this.country = country;
    }
    public String getRegion() {
        return region;
    }
    public void setRegion( String Region ) {
        this.region = region;
    }
    public int getPostalcode() {
        return postalcode;
    }
    public void setPostalcode( int postalcode ) {
        this.postalcode = postalcode;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public int getMetroCode() {
        return metroCode;
    }

    public void setMetroCode(int metroCode) {
        this.metroCode = metroCode;
    }

    public int getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(int areaCode) {
        this.areaCode = areaCode;
    }
}
