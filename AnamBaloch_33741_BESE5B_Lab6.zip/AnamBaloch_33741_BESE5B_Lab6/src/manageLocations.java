import org.hibernate.*;
import org.hibernate.cfg.Configuration;

import java.util.Iterator;
import java.util.List;


public class manageLocations {
    private static SessionFactory factory;

    manageLocations(){
        try{
            factory = new Configuration().configure().buildSessionFactory();
        }catch (Throwable ex) {
            System.err.println("Failed to create sessionFactory object." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public int addEntry7(int id, String co, String re, String ci, String pc, float lat, float lon){
        Session session = factory.openSession();
        Transaction tx = null;
        int id1=0;
        try{
            tx = session.beginTransaction();
            areaLocation al = new areaLocation(id, co, re, ci, pc, lat, lon);
            id1 = (Integer) session.save(al);
            tx.commit();
        }
        catch(HibernateException e){
            if(tx!=null) tx.rollback();
            e.printStackTrace();
        }
        finally{
            session.close();
        }
        return id1;
    }

    public int addEntry9(int id, String co, String re, String ci, String pc, float lat, float lon, int mc, int ac){
        Session session = factory.openSession();
        Transaction tx = null;
        int id1=0;
        try{
            tx = session.beginTransaction();
            areaLocation al = new areaLocation(id, co, re, ci, pc, lat, lon, mc, ac);
            id1 = (Integer) session.save(al);
            tx.commit();
        }
        catch(HibernateException e){
            if(tx!=null) tx.rollback();
            e.printStackTrace();
        }
        finally{
            session.close();
        }
        return id1;
    }
    public void GreatCircle {
            double x1 = Math.toRadians(Double.parseDouble(args[0]));
            double y1 = Math.toRadians(Double.parseDouble(args[1]));
            double x2 = Math.toRadians(Double.parseDouble(args[2]));
            double y2 = Math.toRadians(Double.parseDouble(args[3]));

            /*************************************************************************
             * Compute using law of cosines
             *************************************************************************/
            // great circle distance in radians
            double angle1 = Math.acos(Math.sin(x1) * Math.sin(x2)
                    + Math.cos(x1) * Math.cos(x2) * Math.cos(y1 - y2));

            // convert back to degrees
            angle1 = Math.toDegrees(angle1);

            // each degree on a great circle of Earth is 60 nautical miles
            double distance1 = 60 * angle1;

            System.out.println(distance1 + " nautical miles");


            /*************************************************************************
             * Compute using Haverside formula
             *************************************************************************/
            double a = Math.pow(Math.sin((x2-x1)/2), 2)
                    + Math.cos(x1) * Math.cos(x2) * Math.pow(Math.sin((y2-y1)/2), 2);

            // great circle distance in radians
            double angle2 = 2 * Math.asin(Math.min(1, Math.sqrt(a)));

            // convert back to degrees
            angle2 = Math.toDegrees(angle2);

            // each degree on a great circle of Earth is 60 nautical miles
            double distance2 = 60 * angle2;

            System.out.println(distance2 + " nautical miles");
        }

    }
    public void findlocation(String a){
        Session session = factory.openSession();
        Transaction tx = null;
        try{
            tx = session.beginTransaction();
            List employees = session.createQuery("FROM areaLocation").list();
            for (Iterator iterator =
                 employees.iterator(); iterator.hasNext();){
                areaLocation location = (areaLocation) iterator.next();
                if(a.contentEquals(location.getCity())) {
                    System.out.println("FOUND");
                    System.out.println(location.getLatitude());
                    System.out.println(location.getLongitude());
                    break;
                }


            }
            tx.commit();
        }catch (HibernateException e) {
            if (tx!=null) tx.rollback();
            e.printStackTrace();
        }finally {
            session.close();
        }

    }
}
