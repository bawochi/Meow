Create schema geolocation;
Create table arealocation(
id int NOT NULL AUTO_INCREMENT,
country varchar(50),
region varchar(50),
city varchar(50),
postalCode varchar(50),
latitude float,
longitude float,
metroCode int,
areaCode int,
Primary Key (id));

select * from arealocation;
